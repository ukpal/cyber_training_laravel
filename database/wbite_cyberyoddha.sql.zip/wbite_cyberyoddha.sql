-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 06, 2021 at 02:22 PM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wbite_cyberyoddha`
--
CREATE DATABASE IF NOT EXISTS `wbite_cyberyoddha` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `wbite_cyberyoddha`;

-- --------------------------------------------------------

--
-- Table structure for table `otp`
--

DROP TABLE IF EXISTS `otp`;
CREATE TABLE IF NOT EXISTS `otp` (
  `username` varchar(250) DEFAULT NULL,
  `token` varchar(256) NOT NULL,
  `otp` varchar(6) NOT NULL,
  `otp_created_on` datetime NOT NULL,
  `otp_count` smallint(1) NOT NULL,
  KEY `email` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `token` varchar(256) NOT NULL,
  `email` varchar(120) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `profile_photo` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `is_active` smallint(1) NOT NULL DEFAULT '1',
  `last_login` datetime DEFAULT NULL,
  `is_loggedin` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `phone`, `token`, `email`, `password`, `role`, `profile_photo`, `created_at`, `updated_at`, `is_active`, `last_login`, `is_loggedin`) VALUES
(1, 'SANJOY CHOWDHURY', '8910376939', '9d6a748cdb0f107823f4f0e1ae95be42704cbc206ce47feeda1c04b7b7f84d70db5459972a23e5a52a58c26281cb9c476ce72d3fb55cefd604f615396aadc208', 'sany.chowdhury@gmail.com', NULL, 'SUPERADMIN', '1.jpg', '2021-12-02 21:56:13', NULL, 1, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `yoddha_registrations`
--

DROP TABLE IF EXISTS `yoddha_registrations`;
CREATE TABLE IF NOT EXISTS `yoddha_registrations` (
  `id` int(21) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `is_active` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
